package club.flutterchina.gitme;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
