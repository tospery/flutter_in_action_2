package club.flutterchina.book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
